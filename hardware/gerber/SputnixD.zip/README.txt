README.TXT - Sputnix Rev.D PCB

e-mail: gregelectric@gmail.com

Gerber Files: SputnixD.ZIP
Material: FR4, 0.062�
Layers: 2	
Copper: 1.0oz
Silkscreen: WHITE
Solder Mask: GREEN LPI
Finish: FLASH GOLD/ TIN LEAD HASL
Panelization: ROUTED/V-SCORE
Routing: 
Electrical Test: NO

Special Instructions: 
- note routing for J3, plated

File Contents:
SputnixD.BMK - Solder side mask Gerber
SputnixD.BOT - Solder side copper Gerber
SputnixD.DRL - Drill aperature file
SputnixD.NCD - NC Drill file
SputnixD.TMK - Component side mask Gerber
SputnixD.TOP - Component side copper Gerber
SputnixD.TSK - Component side silkscreen Gerber
